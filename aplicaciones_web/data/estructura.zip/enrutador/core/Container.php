<?php
namespace Core;

/**
 * Class Container
 *
 * Un contenedor de servicios (o contenedor de Inyección de Dependencias - DI) es una
 * herramienta que gestiona las dependencias de la aplicación. En lugar de crear
 * objetos (servicios) manualmente donde se necesitan, se piden al contenedor.
 *
 * Esta implementación es muy simple y actúa más como un "Localizador de Servicios".
 * No construye los objetos, sino que delega la obtención de los mismos.
 * Un contenedor más avanzado tendría métodos para "registrar" (bind) y "resolver" (resolve)
 * servicios, gestionando su ciclo de vida.
 */
class Container
{
    /**
     * Obtiene la instancia del servicio de base de datos.
     *
     * En esta implementación, el método no crea ni almacena la instancia,
     * sino que delega la llamada al método estático `getInstance()` de la
     * propia clase `Database`.
     *
     * Esto significa que la clase `Database` está implementada como un Singleton,
     * un patrón que asegura que solo exista una única instancia de la clase
     * en toda la aplicación.
     *
     * @return \App\services\Database La única instancia del servicio de base de datos.
     */
    public function getDatabase(): \App\services\Database
    {
        // Devuelve la instancia única del servicio de base de datos.
        return \App\services\Database::getInstance();
    }
}