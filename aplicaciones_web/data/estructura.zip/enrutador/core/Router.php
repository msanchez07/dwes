<?php

namespace Core;

/**
 * Class Router
 *
 * Se encarga de gestionar las rutas de la aplicación. Su trabajo es simple pero crucial:
 * toma una URI (la URL que pide el usuario) y decide qué controlador y qué método
 * deben encargarse de responder a esa petición.
 */
class Router
{
    /**
     * @var Container El contenedor de servicios para obtener dependencias.
     */
    private $container;

    /**
     * @var array Almacena todas las rutas definidas en la aplicación.
     */
    private $routes = [];

    /**
     * Router constructor.
     * @param Container $container El contenedor de servicios.
     */
    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    /**
     * Añade las rutas al enrutador.
     * @param array $routes Las rutas definidas en routes.php.
     */
    public function addRoutes(array $routes)
    {
        $this->routes = $routes;
    }

    /**
     * Procesa la URI y despacha al controlador/método correspondiente.
     * @param string $uri La URI solicitada por el usuario.
     */
    public function dispatch($uri)
    {
        // 1. Normalizar la URI.
        // `parse_url` elimina la query string (ej. "?foo=bar").
        // `rtrim` quita la barra final para consistencia (ej. "/users/" -> "/users").
        $uri = parse_url($uri, PHP_URL_PATH);
        $uri = rtrim($uri, '/');
        // Si la URI está vacía después de normalizar (era "/"), la reestablecemos a "/".
        if ($uri === '') {
            $uri = '/';
        }

        // 2. Recorrer todas las rutas definidas para encontrar una que coincida.
        foreach ($this->routes as $route => $handler) {
            // Convertimos la definición de la ruta (ej. '/perfil/{id}') en una expresión regular.
            $pattern = $this->getRoutePattern($route);

            // `preg_match` intenta hacer coincidir la URI con el patrón regex.
            if (preg_match($pattern, $uri, $matches)) {
                
                // 3. Si hay coincidencia, extraemos los parámetros de la URL.
                // `preg_match` llena `$matches` con los resultados. Los parámetros con nombre
                // (ej. 'id') aparecen como claves de string en `$matches`.
                $params = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);

                // 4. Obtenemos el nombre del controlador y del método desde el handler.
                // Ej: ['HomeController', 'index']
                $controllerName = 'App\\controller\\' . $handler[0];
                $methodName = $handler[1];

                // 5. Creamos una instancia del controlador.
                // Aquí usamos el contenedor de servicios para obtener la conexión a la BD,
                // demostrando una forma simple de inyección de dependencias.
                $database = $this->container->getDatabase();
                $controller = new $controllerName($database);

                // 6. Llamamos al método del controlador, pasándole los parámetros extraídos.
                // `call_user_func_array` es una forma de llamar a una función (en este caso, un método)
                // y pasarle los argumentos como un array.
                call_user_func_array([$controller, $methodName], $params);
                
                // Salimos del método dispatch, ya que hemos encontrado y gestionado la ruta.
                return;
            }
        }

        // 7. Si el bucle termina y no hemos encontrado ninguna ruta, es un 404.
        http_response_code(404);
        echo "<h1>404 - Página no encontrada</h1>";
    }

    /**
     * Convierte una cadena de ruta en un patrón de expresión regular.
     * @param string $route La ruta (ej. '/perfil/{id}').
     * @return string El patrón regex (ej. '#^/perfil/(?P<id>[^/]+)$#').
     */
    private function getRoutePattern($route)
    {
        // Escapamos las barras '/' para que no se interpreten como delimitadores de la regex.
        $pattern = str_replace('/', '\\/', $route);

        // Convertimos las variables de ruta (ej. {id}) en grupos de captura con nombre de la regex.
        // Esto nos permite tener rutas dinámicas como /perfil/1, /perfil/2, etc.
        // La regex busca patrones como {param} o {param:regex}.
        $pattern = preg_replace_callback(
            '/\{([a-zA-Z_][a-zA-Z0-9_]*)(?::([^\}]+))?\}/',
            function ($matches) {
                $paramName = $matches[1]; // El nombre del parámetro (ej. 'id')
                $regex = isset($matches[2]) ? $matches[2] : '[^/]+'; // La regex de validación, o '[^/]+' por defecto.
                
                // `(?P<nombre>...)` crea un grupo de captura con nombre.
                // Esto es lo que nos permite luego extraer el valor por su nombre.
                return '(?P<' . $paramName . '>' . $regex . ')';
            },
            $pattern
        );

        // Añadimos anclas de inicio (^) y fin ($) para asegurar que la coincidencia sea exacta
        // y no parcial. Los '#' son los delimitadores de la expresión regular.
        return '#^' . $pattern . '$#';
    }
}

