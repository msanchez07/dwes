<?php

namespace Core;

use App\services\Database;

/**
 * Class Controller
 *
 * Es una clase base abstracta para todos los controladores de la aplicación.
 * Su propósito es centralizar la lógica común que puedan necesitar los controladores.
 *
 * Al ser 'abstract', no se pueden crear instancias directas de esta clase,
 * solo se puede heredar de ella.
 */
abstract class Controller
{
    /**
     * @var Database La instancia del servicio de base de datos.
     * Es 'protected' para que las clases hijas (los controladores concretos) puedan acceder a ella.
     */
    protected $db;

    /**
     * Constructor del controlador.
     *
     * Recibe dependencias (en este caso, el servicio de base de datos) y las
     * almacena para que estén disponibles en los métodos del controlador.
     * Esto es un ejemplo de "Inyección de Dependencias".
     *
     * @param Database $database El servicio de base de datos, inyectado por el Router.
     */
    public function __construct(Database $database)
    {
        $this->db = $database;
    }

    /**
     * Método de ayuda (helper) para cargar una vista.
     *
     * Simplifica la carga de archivos de vista y el paso de datos a las mismas.
     *
     * @param string $viewName El nombre del archivo de la vista (sin la extensión '.view.php').
     * @param array $data Un array asociativo de datos que se deben hacer disponibles en la vista.
     */
    protected function view($viewName, $data = [])
    {
        // La función `extract` es un atajo. Convierte las claves de un array asociativo en variables.
        // Por ejemplo, si $data es ['users' => $allUsers], `extract` crea una variable `$users`
        // que contiene el valor de $allUsers, y que estará disponible en el archivo de la vista.
        extract($data);

        // Construimos la ruta completa al archivo de la vista usando la constante VIEWS_PATH
        // y cargamos el archivo. Como la vista se carga dentro de este método, tendrá acceso
        // a las variables creadas por `extract`.
        require VIEWS_PATH . '/' . $viewName . '.view.php';
    }
}

