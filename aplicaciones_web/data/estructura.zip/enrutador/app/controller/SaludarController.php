<?php

namespace App\controller;

use App\services\Database;
use Core\Controller;

class SaludarController extends Controller
{
    public function __construct(Database $database)
    {
        parent::__construct($database);
    }

    public function saludar($nombre, $apellido)
    {
        // Pasamos las variables a la vista
        // La vista tendrá acceso a $nombre y $apellido
        $this->view('saludar', [
            'nombre' => $nombre,
            'apellido' => $apellido
        ]);
    }
}