<?php
// Archivo: app/controllers/HomeController.php

// CORREGIDO: namespace 'controllers' en minúscula
namespace App\controller;

use App\models\User;
use Core\Controller;

class HomeController extends Controller
{
    public function index()
    {
        $users = User::all($this->db);
        // Cargar la vista home.view.php
        $this->view('home', ['users' => $users]);
    }
}