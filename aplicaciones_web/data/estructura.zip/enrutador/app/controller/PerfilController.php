<?php
// CORRECTO: Namespace 'Controllers' con C mayúscula
namespace App\controller;

use App\models\User;
use Core\Controller;

class PerfilController extends Controller
{
    public function ver($id)
    {
        $user = User::find($this->db, $id);

        // Cargar una vista para el perfil
        $this->view('perfil', ['user' => $user]);
    }
}