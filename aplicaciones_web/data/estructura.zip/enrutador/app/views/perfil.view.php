<!DOCTYPE html>
<html>
<head>
    <title>Perfil de Usuario</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
<div class="container">
    <h1>Perfil de Usuario</h1>
    <?php if (isset($user)): ?>
        <p>ID: <?php echo $user->id; ?></p>
        <p>Nombre: <?php echo $user->name; ?></p>
        <p>Email: <?php echo $user->email; ?></p>
    <?php else: ?>
        <p>Usuario no encontrado.</p>
    <?php endif; ?>
</div>
</body>
</html>
