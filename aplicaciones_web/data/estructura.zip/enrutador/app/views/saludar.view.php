<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Saludo</title>
</head>
<body>
    <h1>Hola, <?= htmlspecialchars($nombre) ?> <?= htmlspecialchars($apellido) ?>!</h1>
</body>
</html>