<!DOCTYPE html>
<html>
<head>
    <title><?= $pageTitle ?></title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
<div class="container">
    <h1>Página de Inicio</h1>
    <p>Bienvenido a la página de inicio.</p>

    <hr>

    <h2>Listado de Usuarios</h2>
    <?php if (isset($users) && !empty($users)): ?>
        <ul>
            <?php foreach ($users as $user): ?>
                <li>
                    <a href="/perfil/<?php echo $user->id; ?>">
                        <?php echo htmlspecialchars($user->name); ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p>No se encontraron usuarios.</p>
    <?php endif; ?>
</div>
</body>
</html>
