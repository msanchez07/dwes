<?php

namespace App\services;

use PDO;
use PDOException;

/**
 * Class Database
 *
 * Implementa el patrón Singleton para gestionar la conexión a la base de datos.
 * Esto asegura que solo haya una única instancia de la conexión a la BD en toda la aplicación,
 * lo cual es eficiente y previene problemas de concurrencia o recursos.
 */
class Database
{
    /**
     * @var PDO La instancia de la conexión PDO a la base de datos.
     */
    private $pdo;

    /**
     * @var Database|null Almacena la única instancia de la clase Database (Singleton).
     */
    private static $instance = null;

    /**
     * Constructor privado para implementar el patrón Singleton.
     *
     * Se encarga de establecer la conexión a la base de datos SQLite.
     * Crea el directorio de la base de datos si no existe y configura PDO.
     */
    private function __construct()
    {
        // Construye la ruta absoluta al archivo de la base de datos SQLite.
        // BASE_PATH es una constante definida en public/index.php.
        $dbPath = BASE_PATH . '/database/database.sqlite';
        $dbDir = dirname($dbPath); // Obtiene el directorio donde debe estar el archivo de la BD.

        try {
            // Asegura que el directorio 'database/' exista.
            if (!is_dir($dbDir)) {
                mkdir($dbDir, 0777, true); // Crea el directorio con permisos de escritura.
            }

            // Establece la conexión PDO (PHP Data Objects) a la base de datos SQLite.
            $this->pdo = new PDO('sqlite:' . $dbPath);
            // Configura PDO para que lance excepciones en caso de errores, facilitando el manejo.
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            // Si hay un error de conexión, detiene la ejecución y muestra un mensaje.
            die("Error de conexión con la base de datos: " . $e->getMessage());
        }
    }

    /**
     * Método estático para obtener la única instancia de la clase Database (Singleton).
     *
     * Si la instancia no existe, la crea; de lo contrario, devuelve la existente.
     *
     * @return Database La única instancia de la conexión a la base de datos.
     */
    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self(); // 'new self()' llama al constructor privado.
        }
        return self::$instance;
    }

    /**
     * Obtiene el objeto PDO para interactuar directamente con la base de datos.
     *
     * @return PDO La instancia de PDO.
     */
    public function getConnection()
    {
        return $this->pdo;
    }

}