<?php

namespace App\models;

use App\services\Database;
use PDO;

/**
 * Class User
 *
 * Representa el modelo de usuario en la aplicación.
 * Los modelos son responsables de interactuar con la base de datos
 * para obtener, guardar, actualizar o eliminar datos relacionados con una entidad (en este caso, 'usuarios').
 *
 * Este modelo utiliza métodos estáticos para simplificar el acceso a los datos,
 * recibiendo la instancia de la base de datos como dependencia.
 */
class User
{
    // Propiedades que reflejarían las columnas de la tabla 'users'
    // public $id;
    // public $name;
    // public $email;
    // ... (otras propiedades si las hubiera)

    /**
     * Obtiene todos los usuarios de la base de datos.
     *
     * @param Database $db La instancia del servicio de base de datos.
     * @return array Un array de objetos `stdClass`, donde cada objeto representa un usuario.
     */
    public static function all(Database $db)
    {
        $pdo = $db->getConnection(); // Obtiene la conexión PDO.
        $stmt = $pdo->query('SELECT * FROM users'); // Ejecuta una consulta para seleccionar todos los usuarios.
        
        // `fetchAll(PDO::FETCH_OBJ)` devuelve un array de objetos genéricos (stdClass),
        // donde las propiedades del objeto corresponden a los nombres de las columnas.
        return $stmt->fetchAll(PDO::FETCH_OBJ);
    }

    /**
     * Obtiene un usuario específico por su ID.
     *
     * @param Database $db La instancia del servicio de base de datos.
     * @param int $id El ID del usuario a buscar.
     * @return object|false Un objeto `stdClass` que representa al usuario, o `false` si no se encuentra.
     */
    public static function find(Database $db, $id)
    {
        $pdo = $db->getConnection(); // Obtiene la conexión PDO.
        
        // Prepara una consulta SQL para evitar inyecciones SQL.
        // `:id` es un marcador de posición para el valor del ID.
        $stmt = $pdo->prepare('SELECT * FROM users WHERE id = :id');
        
        // Ejecuta la consulta, pasando el valor del ID al marcador de posición.
        $stmt->execute(['id' => $id]);
        
        // `fetch(PDO::FETCH_OBJ)` devuelve un único objeto genérico (stdClass)
        // o `false` si no se encuentra ninguna fila.
        return $stmt->fetch(PDO::FETCH_OBJ);
    }
}
