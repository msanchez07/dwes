<?php

/**
 * --------------------------------------------------------------------------
 * PUNTO DE ENTRADA DE LA APLICACIÓN (FRONT CONTROLLER)
 * --------------------------------------------------------------------------
 *
 * Todas las peticiones al servidor se redirigen a este archivo. Su misión es
 * "arrancar" la aplicación:
 *
 * 1. Define constantes y rutas base.
 * 2. Configura el autoloader para cargar clases automáticamente.
 * 3. Inicializa el contenedor de servicios y el enrutador.
 * 4. Recoge la petición del usuario y le dice al enrutador que la gestione.
 *
 * Este patrón se llama "Front Controller" y es fundamental en la mayoría de
 * frameworks modernos, ya que centraliza la gestión de peticiones.
 */

// --- 0. DEFINICIÓN DE CONSTANTES ---
// Para tener rutas absolutas y fiables dentro de la aplicación.

// BASE_PATH: La raíz del proyecto. `dirname(__DIR__)` sube un nivel desde `public` a la raíz.
define('BASE_PATH', dirname(__DIR__));

// VIEWS_PATH: Ruta a la carpeta de vistas. Facilita referenciar vistas desde los controladores.
define('VIEWS_PATH', BASE_PATH . '/app/views');


// --- 1. AUTOLOADING (CARGA AUTOMÁTICA DE CLASES) ---
// Registramos una función que se ejecutará automáticamente cada vez que PHP
// necesite cargar una clase que no conoce.
spl_autoload_register(function ($class) {
    
    // Mapeo de "namespaces" a directorios (según el estándar PSR-4).
    // Esto le dice al autoloader: "Las clases que empiecen con 'App\' están en la carpeta 'app/'".
    $prefixes = [
        'App\\'  => BASE_PATH . '/app/',
        'Core\\' => BASE_PATH . '/core/',
    ];

    // Recorremos el mapa para encontrar el prefijo que corresponde a la clase buscada.
    foreach ($prefixes as $prefix => $base_dir) {
        
        // Comparamos el inicio del nombre de la clase con el prefijo.
        $len = strlen($prefix);
        if (strncmp($prefix, $class, $len) !== 0) {
            // Si no coincide, pasamos al siguiente prefijo del mapa.
            continue;
        }

        // Si coincide, construimos la ruta al archivo.
        // 1. Quitamos el prefijo del nombre de la clase.
        //    Ej: 'App\controller\HomeController' -> 'controller\HomeController'
        $relative_class = substr($class, $len);

        // 2. Reemplazamos las barras invertidas del namespace por las del sistema de archivos.
        //    Ej: 'controller\HomeController' -> 'controller/HomeController.php'
        $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

        // Si el archivo existe en la ruta construida, lo cargamos.
        if (file_exists($file)) {
            require $file;
            return; // Importante: Salimos de la función una vez encontrado el archivo.
        }
    }
});


// --- 2. INICIALIZACIÓN DE LA APLICACIÓN (BOOTSTRAPPING) ---

// 3. CREAR EL CONTENEDOR DE SERVICIOS
// El contenedor es como una "caja de herramientas" donde guardamos
// objetos que queremos que estén disponibles en toda la aplicación (ej: la conexión a la BD).
$container = new Core\Container();

// 4. CREAR EL ENRUTADOR
// El enrutador se encargará de dirigir cada petición a su controlador correspondiente.
// Le pasamos el contenedor para que los controladores puedan usar sus herramientas.
$router = new Core\Router($container);

// 4.1. AÑADIR LAS RUTAS AL ENRUTADOR
// Cargamos el archivo que define qué URI corresponde a qué controlador y método.
$routes = require BASE_PATH . '/routes.php';
$router->addRoutes($routes);

// 5. OBTENER LA URI DE LA PETICIÓN
// `$_SERVER['REQUEST_URI']` contiene la URL que el usuario ha solicitado (ej: "/perfil/1").
$uri = $_SERVER['REQUEST_URI'];

// 6. DESPACHAR LA PETICIÓN
// Le pasamos la URI al enrutador para que busque una coincidencia, cree el
// controlador y ejecute el método correspondiente. Aquí es donde la "magia" ocurre.
$router->dispatch($uri);