# Mini-Framework MVC con Enrutador en PHP

Este proyecto es un pequeño framework didáctico escrito en PHP que implementa un patrón Modelo-Vista-Controlador (MVC) básico y un sistema de enrutamiento.

## Características

-   **Enrutador dinámico**: Permite definir rutas con parámetros (p. ej., `/perfil/{id}`).
-   **Estructura MVC**: Separación de la lógica de negocio, la presentación y el control.
-   **Autoloading PSR-4**: Carga automática de clases siguiendo una estructura de namespaces.
-   **Inyección de Dependencias (Simple)**: Un contenedor de servicios simple para gestionar dependencias como la base de datos.
-   **Controlador Base**: Abstracción para la carga de vistas y paso de datos.

## Estructura del Proyecto

```
/
├── app/
│   ├── controller/  # Controladores (lógica de la aplicación)
│   ├── models/      # Modelos (representación de datos)
│   ├── services/    # Servicios (ej. conexión a BD)
│   └── views/       # Vistas (presentación HTML)
├── core/
│   ├── Container.php # Contenedor de servicios
│   ├── Controller.php# Controlador base
│   └── Router.php    # Clase del enrutador
├── database/
│   └── database.sqlite # Base de datos SQLite
├── public/
│   ├── index.php     # Punto de entrada de la aplicación
│   └── css/          # Archivos CSS
├── routes.php        # Definición de las rutas
└── README.md
```

### Componentes Clave

-   **`public/index.php`**: Es el **punto de entrada único** de la aplicación (Front Controller). Se encarga de:
    1.  Definir constantes globales como `BASE_PATH` y `VIEWS_PATH`.
    2.  Registrar el autoloader para las clases.
    3.  Inicializar el contenedor de servicios y el enrutador.
    4.  Despachar la URI actual para que el enrutador la maneje.

-   **`routes.php`**: Un array asociativo que mapea las URIs a un controlador y un método. Soporta parámetros dinámicos.

    ```php
    return [
        '/' => ['HomeController', 'index'],
        '/perfil/{id}' => ['PerfilController', 'ver'],
    ];
    ```

-   **`core/Router.php`**: La clase principal del enrutamiento. Su método `dispatch` compara la URI de la petición con los patrones definidos en `routes.php`, instancia el controlador correspondiente y ejecuta el método, pasándole los parámetros de la URI.

-   **`core/Controller.php`**: Una clase base `abstracta` de la que heredan todos los controladores. Proporciona:
    -   Un constructor que recibe dependencias (como la base de datos).
    -   Un método `view($viewName, $data = [])` que simplifica la carga de vistas y la transmisión de datos a ellas.

-   **`app/controller/`**: Los controladores gestionan la petición del usuario, interactúan con los modelos y cargan la vista apropiada.

    ```php
    // Ejemplo: HomeController obtiene todos los usuarios y los pasa a la vista
    class HomeController extends Controller
    {
        public function index()
        {
            $users = User::all($this->db);
            $this->view('home', ['users' => $users]);
        }
    }
    ```

-   **`app/models/`**: Los modelos interactúan con la base de datos. Devuelven los datos en forma de objetos estándar (`stdClass`).

    ```php
    class User
    {
        public static function all(Database $db)
        {
            // ...
            return $stmt->fetchAll(PDO::FETCH_OBJ); // Devuelve un array de objetos
        }

        public static function find(Database $db, $id)
        {
            // ...
            return $stmt->fetch(PDO::FETCH_OBJ); // Devuelve un solo objeto
        }
    }
    ```

-   **`app/views/`**: Contienen el código HTML. Los datos pasados desde el controlador están disponibles como variables locales. Como los modelos devuelven objetos, se accede a los datos usando la sintaxis de objeto.

    ```php
    // en home.view.php, iterando sobre la lista de usuarios
    <?php foreach ($users as $user): ?>
        <li>
            <a href="/perfil/<?php echo $user->id; ?>">
                <?php echo htmlspecialchars($user->name); ?>
            </a>
        </li>
    <?php endforeach; ?>
    ```

-   **`core/Container.php`**: Un contenedor de inyección de dependencias muy simple. Se utiliza para registrar y obtener servicios, como la conexión a la base de datos, evitando la necesidad de crear instancias globales.

## Flujo de una Petición (Ej: Página de Inicio)

1.  Toda petición para `/` llega a `public/index.php`.
2.  `index.php` inicializa el `Router`.
3.  El `Router` recibe las rutas de `routes.php`.
4.  El `Router` analiza la URI (`/`) y encuentra la ruta `'/' => ['HomeController', 'index']`.
5.  Instancia el controlador `HomeController`, inyectándole la dependencia `Database` desde el `Container`.
6.  Llama al método `index()` del controlador.
7.  El método `index()` llama a `User::all()` para obtener todos los usuarios de la base de datos. El modelo devuelve un array de objetos.
8.  El controlador llama a `$this->view('home', ['users' => $users])`.
9.  El método `view()` del controlador base extrae los datos (el array `$users` está ahora disponible en la vista) y carga el archivo `app/views/home.view.php`.
10. La vista `home.view.php` itera sobre el array `$users` y muestra el listado.
11. La página se renderiza y se muestra al usuario.

## Cómo Empezar

1.  Clona el repositorio.
2.  Asegúrate de tener un servidor local como Apache o Nginx, o usa el servidor integrado de PHP.
3.  Apunta la raíz de tu servidor al directorio `public/`.
4.  Si usas el servidor de PHP, navega al directorio `public/` y ejecuta:
    ```sh
    php -S localhost:8000
    ```
5.  Abre tu navegador y visita `http://localhost:8000`.
