<?php
/**
 * --------------------------------------------------------------------------
 * DEFINICIÓN DE RUTAS DE LA APLICACIÓN
 * --------------------------------------------------------------------------
 *
 * Este archivo centraliza la configuración de todas las rutas de la aplicación.
 * Cada entrada en el array mapea una URI (Uniform Resource Identifier) a un
 * "handler", que es la combinación de un controlador y un método dentro de ese
 * controlador que se encargará de procesar la petición para esa URI.
 *
 * El formato es:
 * 'URI_PATTERN' => ['NombreDelControlador', 'nombreDelMetodo']
 *
 * El 'NombreDelControlador' debe ser el nombre de la clase del controlador
 * (sin el namespace 'App\controller\', ya que el Router lo añade automáticamente).
 *
 * Las rutas pueden incluir parámetros dinámicos encerrados entre llaves `{}`.
 * Por ejemplo, `{id}` o `{nombre}`. Estos parámetros se pasarán como argumentos
 * al método del controlador.
 *
 * Opcionalmente, se puede especificar una expresión regular para un parámetro
 * usando la sintaxis `{parametro:regex}`. Si no se especifica, se usa una
 * regex por defecto que coincide con cualquier cadena que no contenga una barra `/`.
 */

return [
    // Ruta raíz o página de inicio.
    // Cuando el usuario accede a "/", se ejecuta el método 'index' de 'HomeController'.
    '/' => ['HomeController', 'index'],

    // Otra forma de acceder a la página de inicio.
    '/home' => ['HomeController', 'index'],

    // Ruta para ver el perfil de un usuario específico.
    // `{id}` es un parámetro dinámico que capturará el ID del usuario.
    // El Router pasará este ID como argumento al método 'ver' de 'PerfilController'.
    '/perfil/{id}' => ['PerfilController', 'ver'],

    // Ruta de ejemplo para saludar a alguien con nombre y apellido.
    // `{nombre}` y `{apellido}` son parámetros dinámicos.
    // El Router los pasará como argumentos al método 'saludar' de 'SaludarController'.
    '/saludo/{nombre}/{apellido}' => ['SaludarController', 'saludar'],
];
